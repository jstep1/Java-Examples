import java.util.Scanner;

public class Problem1

{

   public static void main(String[] args)
   
   {
   
      Scanner kbd = new Scanner(System.in);
      
      int n;
      
      do
      
         {
      
         System.out.print("Enter an integer n, greater than 0: ");
      
         n = kbd.nextInt();
         
         }while(n <= 0);
         
      int[] arr = new int[n];
      
      for(int i = 0; i < arr.length; i++)
      
         {
         
         arr[i] = (int)(Math.random() * (500 - 1)) + 1;
         
         }       
      
      System.out.println("Array on one line:");
      
      printArray(arr);
      
      System.out.println("");
      
      System.out.println("Maximum: " + getMax(arr));
      
      System.out.println("Minimum: " + getMin(arr));
      
      System.out.println("Sum: " + sumValues(arr));
      
      System.out.println("Average: " + getAverage(arr));
      
      System.out.println("Number of integers greater than average: " + greaterThanAverage(arr));
      
      System.out.println("Number of times subsequent value increases: " + countInc(arr));
      
      System.out.println("Number of times subsequent value decreases: " + countDec(arr));
      
      System.out.println("Array with 3 elements per line: ");
      
      printArray3PerLn(arr);
      
   }


   public static int getMax(int[] arr)
   
   {
      
      int x = arr[0];
      
      for(int i = 0; i < arr.length; i++)
      
      {
        
         if(arr[i] > x)
         
         {
         
         x = arr[i];
         
         }
         
      }
      
      return x;
      
   }
   
   
   public static int getMin(int[] arr)
   
   {
      
      int x = arr[0];
      
      for(int i = 0; i < arr.length; i++)
      
      {
        
         if(arr[i] < x)
         
         {
         
         x = arr[i];
         
         }
         
      }
      
      return x;
      
   }
   
   
   public static int sumValues(int[] arr)
   
   {
      
      int sum = 0;
      
      for(int i = 0; i < arr.length; i++)
      
      {
        
        sum = sum + arr[i];
        
      }
         
      
      return sum;
      
   }
   
   
   
   public static double getAverage(int[] arr)
   
   {
      
      double sum = 0, count = 0;
      
      for(int i = 0; i < arr.length; i++)
      
      {
        
        sum = sum + arr[i];
        
        count++;
         
      }
      
      double avg = (sum / count);
         
      
      return avg;
      
   }
   
   
   public static int greaterThanAverage(int[] arr)
   
   {
      
      int sum = 0, count = 0, gta = 0;
      
      for(int i = 0; i < arr.length; i++)
      
      {
        
        sum = sum + arr[i];
        
        count++;
         
      }
      
      int avg = (sum / count);
      
      for(int i = 0; i < arr.length; i++)
      
      {
      
         if(arr[i] > avg)
         
         {
         
            gta++;
            
         }
         
      }
      
      return gta;
      
   }
   
   
   public static int countInc(int[] arr)
   
   {
      
      int count = 0;
      
      int x;
      
      for(int i = 1; i < arr.length; i++)
      
      {
      
         x = arr[i - 1];
         
         if(arr[i] > x)
        
         {
            
            count++;
            
         }
       
         
      }
      
      return count;
      
   }
   
   
   public static int countDec(int[] arr)
   
   {
      
      int count = 0;
      
      int x;
      
      for(int i = 1; i < arr.length; i++)
      
      {
      
         x = arr[i - 1];
         
         if(arr[i] < x)
        
         {
            
            count++;
            
         }
       
         
      }
      
      return count;
      
   }
   
   
   public static void printArray(int[] arr)
   
   {
      
      for(int i = 0; i < arr.length; i++)
      
      {
      
         System.out.print(arr[i] + " ");
            
      }
      
      
   }
   
   
   public static void printArray3PerLn(int[] arr)
   
   {
      
      for(int i = 0; i < arr.length; i++)
      
      {
      
         if(i % 3 == 0 || i % 3 == 1)
         
         {
      
         System.out.print(arr[i] + " " );
            
         }
         
         else
         
         {
         
         System.out.println(arr[i]);
         
         }
         
      }
         
         
      }
      
   
   }
   
  